/// AuPLa0301.cpp
/****************************************************************************
AuPLa0301. Sastādīt C++ programmu, kas pieprasa ievadīt N veselus skaitļus un
nosaka lielākā skaitļa vērtību.
*****************************************************************************/
/// Autors: Uldis Straujums
/// Programma izveidota: 16.09.2022.
/// Mainīta: 22.09.2022. Pievienoti komentāri par ieejas datu korektības nodrošināšanu
#include<iostream>
using namespace std;
int main()
{
int n;
int sk;
int liel;
/// Nodrošina ieejas datu korektumu
///  skaitļu skaits n: n>=1
do
{
cout << "Ievadiet skaitļu skaitu N, N>=1: " << endl;
cin >> n;
if(n<1)
    cout << "Nekorekta vērtība, jāievada skaitļu skaits N, N>=1" << endl;
}while(n<1);

/// Izmanto korektu skaitļu skaitu n: n>=1
cout << "Ievadiet  veselu skaitli: " << endl;
cin >> liel;  /// Mainīgais liel ir pašlaik lielākais atrastais skaitlis
for (int i = 0; i < n-1; i++)
   {
    cout << "Ievadiet veselu skaitli: " << endl;
    cin >> sk;
    if (sk > liel) liel = sk;
   }

cout << "Lielākā skaitļa vērtība: " << liel << endl;
}
/******************* Testa plāns ****************************
    N      skaitļi                paredzamais rezultāts
    3      7 -8 17                     17
    1      21                          21
    2     -19 -21                     -19
    2      23 23                       23
    0                                  jāievada N>=1
************************************************************/
