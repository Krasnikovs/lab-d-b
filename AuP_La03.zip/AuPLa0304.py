# AuPLa0304.py
'''
AuPLa0304. Dots naturāls skaitlis n.
Sastādīt Python programmu, kas izdrukā laukumu n × n no simboliem, 
kas atbilst šādam rakstam (pie n=12):
*
**
***
****
*****
******
*******
********
*********
**********
***********
************
'''
# Autors: Uldis Straujums
# Programa izveidota: 20.09.2021.

print("Izdrukā laukumu n × n no simboliem, kas atbilst rakstam")
n = int (input("Ievadiet laukuma izmēru: "))
for k in range(n):
    print((k+1)*'*', end='')
    print()
    
''' Testa plāns 
   n         paredzamais rezultāts
  12          zīmējums no uzdevuma formulējuma
   2          *
              **
   1          *
'''
