# AuPLa0302.py
'''
AuPLa0302. Sastādīt Python+ programmu, kas pieprasa ievadīt N veselus skaitļus un
nosaka lielākā skaitļa vērtību.
'''
# Autors: Uldis Straujums
# Programma izveidota: 22.09.2020.
# Mainīts: 20.09.2022. Pievienoti komentāri par ieejas datu korektības nodrošināšanu

print("Pieprasa ievadīt N veselus skaitļus un nosaka lielākā skaitļa vērtību")
# Nodrošina ieejas datu korektumu
#  skaitļu skaits N: N>=1
n = int(input("Ievadiet skaitļu skaitu N, N>=1: ")) 
while n<1:
    n = int(input("Nekorekta vērtība, ievadiet skaitļu skaitu N, N>=1: "))     
# Izmanto korektu skaitļu skaitu N: N>=1
liel = int(input("Ievadiet veselu skaitli: ")) # Mainīgais liel ir pašlaik lielākais atrastais skaitlis
for i in range(n-1):
    sk = int(input("Ievadiet veselu skaitli: "))
    if sk > liel: liel = sk0
print("Lielākā skaitļa vērtība: ", liel)
    
'''                Testa plāns 
    N      skaitļi                paredzamais rezultāts
    3      7 -8 17                     17
    1      21                          21
    2     -19 -21                     -19
    2      23 23                       23
    0                                  jāievada N>=1
'''