# AuPLa03_papildus.py
'''
AuPLa03_papildus. Dots naturāls skaitlis n.
Sastādīt C++ un Python programmas, kas izdrukā laukumu n × n no simboliem, 
kas atbilst šādam rakstam (pie n=13):

*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
'''
# Autors: Jānis Zuters
# Mainīts: 17.09.2019. izveidota realizācija Python valodā - Uldis Straujums
n = int(input("Ievadiet laukuma izmēru: "))
for i in range(n): # drukā n rindiņas
    for k in range(n): # drukā vienu rindiņu
        if k%3 == i%3:
            print('*', end='') # drukā '*' katru 3-šo reizi,
                                # turklāt 1.rindiņā drukā 1.kolonnā, 4.kolonnā, utt,
                                # 2. rindiņā drukā 2.kolonnā, 5.kolonnā, utt.
        else:
            print('-', end='')
    print()
''' Testa plāns 
  n        paredzamais rezultāts
 13         zīmējums no uzdevuma formulējuma
  2          *-
             -*
  1          *
'''
