/// AuPLa03_papildus.cpp
/******************************
AuPLa03_papildus. Dots naturāls skaitlis n.
Sastādīt C++ un Python programmas, kas izdrukā laukumu n × n no simboliem, kas atbilst šādam rakstam (pie n=13):

*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
-*--*--*--*--
--*--*--*--*-
*--*--*--*--*
**********************************/
/// Autors: Jānis Zuters
/// Mainīts: 20.09.2012. latviskots, pievienoti komentāri - Uldis Straujums

#include <iostream>
using namespace std;

int main()
{
   int n; /// Laukuma izmērs

cout << "Ievadiet laukuma izmēru" << endl;
cin >> n;

for (int i=0;i<n;i++) /// drukā n rindiņas
{
    for (int k=0;k<n; k++) /// drukā vienu rindiņu
    {
     if (k%3 == i%3) cout << '*';  /// drukā '*' katru 3-šo reizi,
                                   /// turklāt 1.rindiņā drukā 1.kolonnā, 4.kolonnā, utt,
                                   /// 2. rindiņā drukā 2.kolonnā, 5.kolonnā, utt.
     else cout << '-';
    }
    cout << endl;
}
}
/************* Testa plāns ***********************
  n          paredzamais rezultāts
 13         zīmējums no uzdevuma formulējuma
  2          *-
             -*
  1          *
*************************************************/
