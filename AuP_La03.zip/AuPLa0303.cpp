/// AuPLa0303.cpp
/***************************************************************
AuPLa0303. Dots naturāls skaitlis n.
Sastādīt C++ programmu, kas izdrukā laukumu n × n no simboliem,
kas atbilst šādam rakstam (pie n=12):

*
**
***
****
*****
******
*******
********
*********
**********
***********
************

*************************************************************/
/// Autors: Uldis Straujums
/// Programma izveidota: 22.09.2020.

#include <iostream>
using namespace std;

int main()
{
int n;
cout << "Ievadiet laukuma izmēru: " << endl;
cin >> n;

for (int i=0;i<n;i++) /// drukā n rindiņas
{
    for (int k=0;k<i+1; k++) /// drukā vienu rindiņu
    {
     cout << '*';
    }
    cout << endl;
}
}
/************* Testa plāns ***********************
  n          paredzamais rezultāts
  12         zīmējums no uzdevuma formulējuma
  2          *
             **
  1          *
*************************************************/
