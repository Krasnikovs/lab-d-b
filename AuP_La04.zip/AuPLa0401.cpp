/// AuPLa0401.cpp
/****************************************************************************
AuPLa0401. Sastādīt C++ programmu, kas pieprasa ievadīt N veselus skaitļus un
nosaka garākās stingri augošas virknes garumu.
Jābūt iespējai programmu izpildīt atkārtoti, neizejot no programmas.
*****************************************************************************/
/// Autors: Uldis Straujums
/// Programma izveidota: 26.09.2022.
/// Mainīts: 26.09.2024. Izlabota vairāku stingri augošu virkņu apstrāde

#include<iostream>
using namespace std;
int main()
{
cout << "Pieprasa ievadīt N veselus skaitļus un " << endl;
cout << "nosaka garākās stingri augošas virknes garumu" << endl;
cout << endl;
  int ok;
do
{
   int n;
   int sk; /// Kārtējais ievadītais skaitlis
   int iepr; /// Iepriekšējais ievadītais skaitlis
   int kgar; /// Kandidāts garākās stingri augošas virknes garumam
   int lgar; /// Pašlaik garākās stingri augošas virknes garums

    /// Nodrošina korekta skaitļu skaita n,n>=1 ievadīšanu
    do
    {
    cout <<"Ievadiet skaitļu skaitu N,N>=1: "<<endl;
    cin >> n;
    if(n<1)cout<<"Kļūdaina vērtība. Jāievada N,N>=1."<<endl;
    }while(n<1);

    /// Saņem korektu skaitļu skaitu n,n>=1
    /// nosaka garākās stingri augošas virknes garumu lgar
    cout <<"Ievadiet veselu skaitli: "<<endl;
    cin >> iepr;
    lgar = kgar = 1; /// Vienīgais ievadītais skaitlis veido
                     /// stingri augošu virkni ar garumu 1
    for(int i=0;i<n-1;i++)
    {
      cout <<"Ievadiet veselu skaitli: "<<endl;
      cin >> sk;
      if(sk>iepr) kgar++;
      else if(kgar>lgar){lgar=kgar; kgar = 1;}
      else kgar = 1;
      iepr = sk;
    }
    if(kgar>lgar) lgar=kgar;

    /// Paziņo rezultātu lgar
    cout<<"Garākās stingri augošas virknes garums: "<<lgar<<endl;

  cout << " Vai turpināt (1) vai beigt (0)?" << endl;
  cin >> ok;
} while (ok == 1);

}
/************  Testa plāns **************
 N   skaitļi           paredzamais rezultāts
 8   1 2 3 1 2 1 2 3    3
 5   20 1 2 3 17        4
 4   1 2 17 20          4
 0                      Kļūdaina vērtība
 1   12                 1
 ****************************************/
