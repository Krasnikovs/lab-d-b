/// AuPLa0403.cpp
/**************************************************************
AuPLa0403. Sastādīt C++ programmu, kas dotam naturālam skaitlim
nosaka lielāko ciparu pierakstā.
Risinājuma iegūšanai sastādīt funkciju,
kura naturālam skaitlim nosaka lielāko ciparu pierakstā.
Jābūt iespējai programmu izpildīt atkārtoti, neizejot no programmas.
***************************************************************/
/// Autors: Uldis Straujums
/// Programma izveidota: 28.09.2021.
/// Mainīts: 26.09.2024. Saīsināta funkcijas realizācija

#include <iostream>
using namespace std;
/********************************************************
int lielcip(int n);
Funkcija lielcip(n) -
 nosaka lielāko ciparu naturāla skaitļa n pierakstā.
 Atgriež kā rezultātu lielāko ciparu.
*********************************************************/
int lielcip(int n)
{
int lcip = n%10;
do
{
n/=10;
if (n%10>lcip) lcip=n%10;
}while(n>0);
return lcip;
}

int main()
{
cout << "Dotam naturālam skaitlim nosaka lielāko ciparu "<< endl;
cout << endl;
int ok;
do
{
int n;
int liel;
do
{
cout << "Ievadiet naturālu skaitli N, N>=1: "<< endl;
cin >> n;
if(n<1) cout <<"Kļūdaina vērtība. Jāievada N, N>=1." << endl;
}while(n<1);

liel= lielcip(n);
cout << "Naturālā skaitļa " << n << " lielākais cipars ir "
     <<  liel << endl;

cout << endl;
cout << " Vai turpināt (1) vai beigt (0)?" << endl;
cin >> ok;
}while (ok == 1);
}

/**************** Testa plāns ***************
 skaitlis         paredzamais rezultāts
   321               3
    2                2
    -1              Kļūdaina vērtība
   44444             4
********************************************/
