/// AuPLa04_papildus.cpp
/******************************
AuPLa04_papildus. Dots naturāls skaitlis n.
Sastādīt C++ un Python programmas,
kas izdrukā laukumu n × n no simboliem,
kas atbilst šādam rakstam (pie n=7):
*
**
***
****
***
**
*
**********************************/
/// Autors: Uldis Straujums
/// Programma izveidota: 22.09.2020.
/// Mainīts: 24.09.2024. Uzlabota izdruka, lai vienmēr izdrukātu n rindiņas

#include <iostream>
using namespace std;
int main()
{
cout << "Izdrukā laukumu n × n no simboliem, kas atbilst rakstam" <<endl;
cout << endl;
int ok;
do
{
int n;
/// Saņem izmēru
cout << "Ievadiet laukuma izmēru: " << endl;
cin >> n;

/// Paziņo rezultātu - izdrukāto laukumu
/// drukā pirmo pusi no rindiņām
for (int i=0;i<n/2;i++)
{
    for (int k=0;k<i+1; k++) /// drukā vienu rindiņu
    {
     cout << '*';
    }
    cout << endl;
}
/// drukā otro pusi no rindiņām
for (int i=(n+1)/2;i>0;i--)
{
    for (int k=0;k<i; k++) /// drukā vienu rindiņu
    {
     cout << '*';
    }
    cout << endl;
}
cout << " Vai turpināt (1) vai beigt (0)?" << endl;
cin >> ok;
}while (ok == 1);

return 0;
}

/************* Testa plāns ***********************
  n          paredzamais rezultāts
  7         zīmējums no uzdevuma formulējuma
  4          *
             **
             **
             *
  3          *
             **
             *
  1          *
*************************************************/
