# AuPLa0404.py
'''
AuPLa0404. Sastādīt Python programmu, kas dotam naturālam skaitlim nosaka 
lielāko ciparu pierakstā. 
Risinājuma iegūšanai sastādīt funkciju, 
kura naturālam skaitlim nosaka lielāko ciparu pierakstā.
Jābūt iespējai programmu izpildīt atkārtoti, neizejot no programmas.
'''
# Autors: Uldis Straujums
# Programma izveidota: 24.09.2019.
# Mainīts: 26.09.2024. Saīsināta funkcijas realizācija

'''
Funkcija lielcip(n) -
 nosaka lielāko ciparu naturāla skaitļa n pierakstā.
 Atgriež kā rezultātu lielāko ciparu.
'''
def lielcip(n):
   lcip = n%10
   while n > 0:
       n//=10
       if n%10 > lcip: lcip = n%10    
   return lcip;

print("Dotam naturālam skaitlim nosaka lielāko ciparu ")
ok = 1
while ok == 1:
   n = int(input("Ievadiet naturālu skaitli N, N>=1: ")) 
   while n<1:
      n = int(input("Kļūdaina vērtība. Ievadiet N, N>=1: "))
   liel = lielcip(n)
   print("Naturāla skaitļa", n, "lielākais cipars ir", liel)      
   ok = int(input(" Vai turpināt (1) vai beigt (0)? "))   

'''          Testa plāns 
skaitlis         paredzamais rezultāts
   321               3
    2                2
    -1              Kļūdaina vērtība
   44444             4 
'''
