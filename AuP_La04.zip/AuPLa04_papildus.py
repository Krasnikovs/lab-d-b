# AuPLa04_papildus.py
'''
AuPLa04_papildus. Dots naturāls skaitlis n.
Sastādīt C++ un Python programmas,
kas izdrukā laukumu n × n no simboliem,
kas atbilst šādam rakstam (pie n=7):
*
**
***
****
***
**
*
'''
# Autors: Uldis Straujums
# Programma izveidota: 20.09.2021.
# Mainīts: 24.09.2024. Uzlabota izdruka, lai vienmēr izdrukātu n rindiņas

print("Izdrukā laukumu n × n no simboliem, kas atbilst rakstam")
ok = 1
while ok == 1: 
    n = int (input("Ievadiet laukuma izmēru: "))
   # drukā pirmo pusi no rindiņām   
    for i in range(n//2):        
        for k in range(i+1):
            print('*', end='')
        print()
   # drukā otro pusi no rindiņām 
    for i in range((n+1)//2,0,-1):   
        for k in range(i):
            print('*', end='') 
        print()

    ok = int(input("Vai turpināt (1) vai beigt (0)?"))
 
''' Testa plāns 
n          paredzamais rezultāts
7         zīmējums no uzdevuma formulējuma
4          *
           **
           **
           *
3          *
           **
           *
1          *
'''