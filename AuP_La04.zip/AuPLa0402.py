# AuPLa0402.py
'''
AuPLa0402. Sastādīt Python programmu, kas pieprasa ievadīt N veselus skaitļus un 
nosaka garākās stingri augošas virknes garumu.
Jābūt iespējai programmu izpildīt atkārtoti, neizejot no programmas.
'''
# Autors: Uldis Straujums
# Programma izveidota: 26.09.2022.
# Mainīts: 26.09.2024. Izlabota vairāku stingri augošu virkņu apstrāde

print("Pieprasa ievadīt N veselus skaitļus un nosaka garākās stingri augošas virknes garumu")
ok = 1
while ok == 1:
    # Nodrošina ieejas datu korektumu
    #  skaitļu skaits N, N>=1
    N = int(input("Ievadiet skaitļu skaitu N, N>=1: ")) 
    while N<1:
        N = int(input("Nekorekta vērtība. Ievadiet skaitļu skaitu N, N>=1: ")) 
    
    # Saņem korektu skaitļu skaitu N, N>=1
    # Nosaka garākās stingri augošas virknes garumu lgar
    iepr = int(input("Ievadiet veselu skaitli: ")) # Pašlaik virknes ievadītais vienīgais elements -
                                                  # ievadīts pirms cikla, lai būtu ar ko salīdzināt ciklā pirmo ievadīto elementu
    kgar = 1; # kandidāts garākās stingri augošas virknes garumam
    lgar = 1; # pašlaik garākās stingri augošas virknes garums
    for i in range(N-1):
        sk = int(input("Ievadiet veselu skaitli: "))
        if sk > iepr: kgar+=1
        elif kgar > lgar: 
            lgar = kgar 
            kgar = 1
        else: kgar = 1
        iepr = sk
    if kgar > lgar: lgar = kgar
    
    # paziņo rezultātu lgar
    print("Garākās stingri augošas virknes garums:", lgar)
    ok = int(input(" Vai turpināt (1) vai beigt (0)? ")) 
    
'''           Testa plāns 
N   skaitļi           paredzamais rezultāts
 8   1 2 3 1 2 1 2 3    3
 5   20 1 2 3 17        4
 4   1 2 17 20          4
 0                      Kļūdaina vērtība
 1   12                 1
'''